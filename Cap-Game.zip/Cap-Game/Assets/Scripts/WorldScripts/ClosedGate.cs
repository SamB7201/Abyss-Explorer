﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClosedGate : MonoBehaviour
{
    public GameObject key1;
    public GameObject key2;
    public GameObject key3;
    public GameObject LevelGate;

    private bool key1_collected = true;
    private bool key2_collected = true;
    private bool key3_collected = true;

    int count = 0;

    // Start is called before the first frame update
    void Start()
    {
        if(key1 != null)
        {
            count++;
            key1_collected = false;
        }
        if (key2 != null)
        {
            count++;
            key2_collected = false;
        }
        if (key3 != null)
        {
            count++;
            key3_collected = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (key1 == null && key1_collected == false)
        {
            count--;
            key1_collected = true;
        }
        if (key2 == null && key2_collected == false)
        {
            count--;
            key2_collected = true;
        }
        if (key3 == null && key3_collected == false)
        {
            count--;
            key3_collected = true;
        }


        if (count == 0)
        {
            gameObject.SetActive(false);
            LevelGate.SetActive(true);
        }
    }
}
