﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Key : MonoBehaviour
{
    AudioSource Collect;

    private void Start()
    {
        Collect = GetComponent<AudioSource>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.name == "Player")
        {
            Collect.Play();
            Invoke("destroy", 0.15f);
        }
    }

    private void destroy()
    {
        Destroy(gameObject);
    }
}
