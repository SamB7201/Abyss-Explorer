﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Enemy : MonoBehaviour
{
    //move speed
    public float speed = 2.5f;

    //upward push force
    public float upForce = 800;

    //AudioSource deathSound, playerDeathSound;

    //current move direction
    Vector2 dir = Vector2.right;

    private void Start()
    {
        //deathSound = GetComponent<AudioSource>();
        //playerDeathSound = GetComponent<AudioSource>();
    }

    private void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = dir * speed;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //hit a destination? Then move into other direction
        transform.localScale = new Vector2(-1 * transform.localScale.x, transform.localScale.y);

        //add mirror
        dir = new Vector2(-1 * dir.x, dir.y);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Player")
        {
            //Is the collision above
            if (collision.contacts[0].point.y > transform.position.y)
            {
                GetComponent<Animator>().SetTrigger("Died");

                GetComponent<Collider2D>().enabled = false;
                speed = 0;

                collision.gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up * upForce);
                Destroy(gameObject);
                //Die in a few seconds
                //deathSound.PlayOneShot(Resources.Load<AudioClip>("Zero Rare/Retro Sound Effects/Audio/Game Over/game_over_19"));
                //Invoke("Die", 5);
            }
            else
            {
                Destroy(collision.gameObject);
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }
    }
}
