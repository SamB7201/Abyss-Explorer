﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDeath : MonoBehaviour
{
    AudioSource DeathSound;
    public GameObject EnemyBody;
    bool soundPlayed = false;

    // Start is called before the first frame update
    void Start()
    {
        DeathSound = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if(EnemyBody == null && !soundPlayed)
        {
            DeathSound.Play();
            soundPlayed = true;
        }
    }
}
