﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private Rigidbody2D rb;
    public float moveSpeed = 10;
    [Range(0, 1)] public float sliding = 0.9f;
    public float jumpSpeed = 900;
    
    
    private bool isGrounded;
    private bool isTouchingLeft;
    private bool isTouchingRight;
    private bool wallJumping;
    private float touchingLeftOrRight;

    public LayerMask groundMask;
    AudioSource jumpSound;

    private void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>();
        jumpSound = GetComponent<AudioSource>();
    }

    private void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");
        Vector2 v = GetComponent<Rigidbody2D>().velocity;

        if (h != 0)
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(h * moveSpeed, v.y);
            transform.localScale = new Vector2(Mathf.Sign(h), transform.localScale.y);
        }
        else
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(v.x * sliding, v.y);
        }
        GetComponent<Animator>().SetFloat("Speed", Mathf.Abs(h));

        isGrounded = Physics2D.OverlapBox(new Vector2(gameObject.transform.position.x, gameObject.transform.position.y - 0.5f),
            new Vector2(0.5f, 0.1f), 0f, groundMask);

        isTouchingLeft = Physics2D.OverlapBox(new Vector2(gameObject.transform.position.x - 0.4f, gameObject.transform.position.y),
            new Vector2(0.2f, 0.85f), 0f, groundMask);

        isTouchingRight = Physics2D.OverlapBox(new Vector2(gameObject.transform.position.x + 0.4f, gameObject.transform.position.y),
            new Vector2(0.2f, 0.85f), 0f, groundMask);

        //------JUMP--------------------------------------------
        if (Input.GetKey(KeyCode.UpArrow) && isGrounded)
        {
            rb.AddForce(Vector2.up * jumpSpeed);
            jumpSound.Play();
        }
        GetComponent<Animator>().SetBool("Grounded", isGrounded);
        //------End Jump-----------------------------------------

        if (isTouchingLeft)
        {
            touchingLeftOrRight = 1;
        }
        else if (isTouchingRight)
        {
            touchingLeftOrRight = -1;
        }

        if(Input.GetKey(KeyCode.UpArrow) && (isTouchingLeft || isTouchingRight) && !isGrounded)
        {
            wallJumping = true;
            Invoke("SetJumpingFalse", 0.08f);
        }

        if (wallJumping)
        {
            rb.velocity = new Vector2(30f * touchingLeftOrRight, 20f);
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawCube(new Vector2(gameObject.transform.position.x, gameObject.transform.position.y - 0.5f), new Vector2(0.5f, 0.1f));

        Gizmos.color = Color.blue;
        Gizmos.DrawCube(new Vector2(gameObject.transform.position.x - 0.4f, gameObject.transform.position.y), new Vector2(0.1f, 0.85f));
        Gizmos.DrawCube(new Vector2(gameObject.transform.position.x + 0.4f, gameObject.transform.position.y), new Vector2(0.1f, 0.85f));
    }

    void SetJumpingFalse()
    {
        wallJumping = false;
    }
}
