﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretAI : MonoBehaviour
{
    [SerializeField] private float scanRadius = 9f;
    [SerializeField] private LayerMask layers;
    [SerializeField] private GameObject EnemyShot;
    [SerializeField] private Transform firepoint1;
    [SerializeField] private float fireDelay = 3f;

    private Collider2D target;
    private AudioSource FireSound;

    private void Start()
    {
        FireSound = GetComponent<AudioSource>();
        InvokeRepeating("Fire", 0f, fireDelay);
    }

    private void Update()
    {
        CheckEnviroment();
        lookAtTarget();
    }

    void CheckEnviroment()
    {
        target = Physics2D.OverlapCircle(transform.position, scanRadius, layers);
    }

    private void lookAtTarget()
    {
        if (target != null)
        {
            Vector2 direction = target.transform.position - transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90;
            transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
    }

    private void Fire()
    {
        if (target != null)
        {
            Instantiate(EnemyShot, firepoint1.position, firepoint1.rotation);
            FireSound.Play();
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, scanRadius);
    }
}
