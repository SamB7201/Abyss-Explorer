﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowTrap : MonoBehaviour
{
    [SerializeField] private GameObject Arrows;
    [SerializeField] private Transform firepoint1;
    [SerializeField] private float fireDelay = 3f;
    [SerializeField] private float startDelay = 0f;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Fire", startDelay, fireDelay);
    }

    private void Fire()
    {
        Instantiate(Arrows, firepoint1.position, firepoint1.rotation);
    }
}
